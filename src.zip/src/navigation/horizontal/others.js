export default [
  {
    header: 'Help & Support',
    submenu : ["Manual","Bank Manual"],
  },
  // {
  //   title: "Manual",
  //   icon: "HelpCircleIcon",
  //   children: [
  //     {
  //       title: "Manual",
  //       route: "",
  //     },
  //     {
  //       title: "Bank Manual",
  //       route: "",
  //     },
  //   ],
  // },

  // {
  //   title: "Contact Admin",
  //   icon: "AlertTriangleIcon",
  //   children: [
  //     {
  //       title: "About Us",
  //       route: "",
  //     },
  //     {
  //       title: "All Service",
  //       route: "",
  //     },
  //     {
  //       title: "Contact Admin",
  //       route: "",
  //     },
  //   ],
  // },
  
]
